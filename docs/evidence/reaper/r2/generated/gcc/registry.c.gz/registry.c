#include "turbotuv_reaper.h"
extern const tt_reaper_kernels tt_generated_0;
extern const tt_reaper_kernels tt_generated_1;
const tt_reaper_kernels *const *tt_reaper_builtin_tables(size_t *count) {
    static const tt_reaper_kernels *const tables[] = {&tt_generated_0,&tt_generated_1};
    *count = sizeof tables / sizeof *tables;
    return tables;
}
