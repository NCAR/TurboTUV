/* Copyright (C) 2026 University Corporation for Atmospheric Research
 * SPDX-License-Identifier: Apache-2.0 */
#ifndef TT_REAPER_MATH_H
#define TT_REAPER_MATH_H
#include <fenv.h>
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

/* Experimental, bounded binary64 exponential. The ordinary paths retain
 * libm. See docs/REAPER_MATH.md for the independent error bound. */
static inline int tt_reaper_binary64(void) {
#if FLT_RADIX == 2 && DBL_MANT_DIG == 53 && DBL_MAX_EXP == 1024 && DBL_MIN_EXP == -1021
    if (sizeof(double) != sizeof(uint64_t))
        return 0;
    double one = 1.0;
    uint64_t bits = 0;
    memcpy(&bits, &one, sizeof bits);
    return bits == UINT64_C(0x3ff0000000000000);
#else
    return 0;
#endif
}

/* In-place use is supported. All exceptional and out-of-domain operands use
 * libm, including arguments whose result could be subnormal. */
static inline void tt_reaper_exp_array(size_t count, const double *arg, double *out) {
    if (!tt_reaper_binary64() || fegetround() != FE_TONEAREST) {
        for (size_t i = 0; i < count; ++i)
            out[i] = exp(arg[i]);
        return;
    }
    /* Bounded blocks preserve original operands for exceptional in-place
     * lanes, while permitting an unconditional arithmetic vector loop. */
    for (size_t first = 0; first < count; first += 64) {
        size_t n = count - first < 64 ? count - first : 64;
        double original[64];
        int invalid = 0;
        for (size_t i = 0; i < n; ++i) {
            original[i] = arg[first + i];
            invalid |= !((original[i] >= -600) & (original[i] <= 600));
        }
        for (size_t i = 0; i < n; ++i) {
            double x = original[i];
            x = ((x >= -600) & (x <= 600)) ? x : 0;
            double q = x * 0x1.71547652b82fep+0;
            int k = (int)(q + copysign(0.5, q));
            double r = fma(-(double)k, 0x1.a39ef35793c76p-33,
                           x - (double)k * 0x1.62e42fee00000p-1);
            double p = 0x1.6124613a86d09p-33;
            p = fma(p, r, 0x1.1eed8eff8d898p-29);
            p = fma(p, r, 0x1.ae64567f544e4p-26);
            p = fma(p, r, 0x1.27e4fb7789f5cp-22);
            p = fma(p, r, 0x1.71de3a556c734p-19);
            p = fma(p, r, 0x1.a01a01a01a01ap-16);
            p = fma(p, r, 0x1.a01a01a01a01ap-13);
            p = fma(p, r, 0x1.6c16c16c16c17p-10);
            p = fma(p, r, 0x1.1111111111111p-7);
            p = fma(p, r, 0x1.5555555555555p-5);
            p = fma(p, r, 0x1.5555555555555p-3);
            p = fma(p, r, 0x1p-1);
            p = fma(p, r, 0x1p+0);
            p = fma(p, r, 0x1p+0);
            uint64_t bits = (uint64_t)(k + 1023) << 52;
            double scale;
            memcpy(&scale, &bits, sizeof bits);
            out[first + i] = scale * p;
        }
        if (invalid)
            for (size_t i = 0; i < n; ++i)
                if (!((original[i] >= -600) & (original[i] <= 600)))
                    out[first + i] = exp(original[i]);
    }
}
#endif
