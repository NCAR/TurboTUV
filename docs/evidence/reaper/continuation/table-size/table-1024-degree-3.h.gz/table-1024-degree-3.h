/* Copyright (C) 2026 University Corporation for Atmospheric Research
 * SPDX-License-Identifier: Apache-2.0 */
#ifndef TT_REAPER_MATH_H
#define TT_REAPER_MATH_H
#include <fenv.h>
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

/* Experimental, bounded binary64 exponential. The ordinary paths retain
 * libm. See docs/REAPER_MATH.md for the independent error bound. */
static inline int tt_reaper_binary64(void) {
#if FLT_RADIX == 2 && DBL_MANT_DIG == 53 && DBL_MAX_EXP == 1024 && DBL_MIN_EXP == -1021
    if (sizeof(double) != sizeof(uint64_t))
        return 0;
    double one = 1.0;
    uint64_t bits = 0;
    memcpy(&bits, &one, sizeof bits);
    return bits == UINT64_C(0x3ff0000000000000);
#else
    return 0;
#endif
}

/* In-place use is supported. All exceptional and out-of-domain operands use
 * libm, including arguments whose result could be subnormal. */
static inline void tt_reaper_exponential_array(size_t count, const double *arg, double *out,
                                               int base10) {
    if (!tt_reaper_binary64() || fegetround() != FE_TONEAREST) {
        for (size_t i = 0; i < count; ++i)
            out[i] = base10 ? pow(10, arg[i]) : exp(arg[i]);
        return;
    }
    static const double powers[1024] = {
        0x1.0000000000000p+0, 0x1.002c605e2e8cfp+0, 0x1.0058c86da1c0ap+0, 0x1.0085382faef83p+0,
        0x1.00b1afa5abcbfp+0, 0x1.00de2ed0ee0f5p+0, 0x1.010ab5b2cbd11p+0, 0x1.0137444c9b5b5p+0,
        0x1.0163da9fb3335p+0, 0x1.019078ad6a19fp+0, 0x1.01bd1e77170b4p+0, 0x1.01e9cbfe113efp+0,
        0x1.02168143b0281p+0, 0x1.02433e494b755p+0, 0x1.027003103b10ep+0, 0x1.029ccf99d720ap+0,
        0x1.02c9a3e778061p+0, 0x1.02f67ffa765e6p+0, 0x1.032363d42b027p+0, 0x1.03504f75ef071p+0,
        0x1.037d42e11bbccp+0, 0x1.03aa3e170aafep+0, 0x1.03d7411915a8ap+0, 0x1.04044be896ab6p+0,
        0x1.04315e86e7f85p+0, 0x1.045e78f5640b9p+0, 0x1.048b9b35659d8p+0, 0x1.04b8c54847a28p+0,
        0x1.04e5f72f654b1p+0, 0x1.051330ec1a03fp+0, 0x1.0540727fc1762p+0, 0x1.056dbbebb786bp+0,
        0x1.059b0d3158574p+0, 0x1.05c866520045bp+0, 0x1.05f5c74f0bec2p+0, 0x1.06233029d8216p+0,
        0x1.0650a0e3c1f89p+0, 0x1.067e197e26c14p+0, 0x1.06ab99fa6407cp+0, 0x1.06d92259d794dp+0,
        0x1.0706b29ddf6dep+0, 0x1.07344ac7d9d51p+0, 0x1.0761ead925493p+0, 0x1.078f92d32085dp+0,
        0x1.07bd42b72a836p+0, 0x1.07eafa86a2771p+0, 0x1.0818ba42e7d30p+0, 0x1.084681ed5a462p+0,
        0x1.0874518759bc8p+0, 0x1.08a22912465f2p+0, 0x1.08d0088f8093fp+0, 0x1.08fdf00068fe2p+0,
        0x1.092bdf66607e0p+0, 0x1.0959d6c2c830dp+0, 0x1.0987d61701716p+0, 0x1.09b5dd646dd77p+0,
        0x1.09e3ecac6f383p+0, 0x1.0a1203f067a63p+0, 0x1.0a402331b9715p+0, 0x1.0a6e4a71c726ep+0,
        0x1.0a9c79b1f3919p+0, 0x1.0acab0f3a1b9cp+0, 0x1.0af8f03834e52p+0, 0x1.0b27378110974p+0,
        0x1.0b5586cf9890fp+0, 0x1.0b83de2530d11p+0, 0x1.0bb23d833d93fp+0, 0x1.0be0a4eb2353bp+0,
        0x1.0c0f145e46c85p+0, 0x1.0c3d8bde0ce7ap+0, 0x1.0c6c0b6bdae53p+0, 0x1.0c9a93091632ap+0,
        0x1.0cc922b7247f7p+0, 0x1.0cf7ba776bb94p+0, 0x1.0d265a4b520bap+0, 0x1.0d5502343de02p+0,
        0x1.0d83b23395decp+0, 0x1.0db26a4ac0ed5p+0, 0x1.0de12a7b26300p+0, 0x1.0e0ff2c62d096p+0,
        0x1.0e3ec32d3d1a2p+0, 0x1.0e6d9bb1be415p+0, 0x1.0e9c7c55189c6p+0, 0x1.0ecb6518b4874p+0,
        0x1.0efa55fdfa9c5p+0, 0x1.0f294f0653b45p+0, 0x1.0f58503328e6dp+0, 0x1.0f875985e389bp+0,
        0x1.0fb66affed31bp+0, 0x1.0fe584a2afb21p+0, 0x1.1014a66f951cep+0, 0x1.1043d06807c2fp+0,
        0x1.1073028d7233ep+0, 0x1.10a23ce13f3e2p+0, 0x1.10d17f64d9ef1p+0, 0x1.1100ca19ad92fp+0,
        0x1.11301d0125b51p+0, 0x1.115f781cae1fap+0, 0x1.118edb6db2dc1p+0, 0x1.11be46f5a032cp+0,
        0x1.11edbab5e2ab6p+0, 0x1.121d36afe70c9p+0, 0x1.124cbae51a5c8p+0, 0x1.127c4756e9e05p+0,
        0x1.12abdc06c31ccp+0, 0x1.12db78f613d5bp+0, 0x1.130b1e264a0e9p+0, 0x1.133acb98d40a2p+0,
        0x1.136a814f204abp+0, 0x1.139a3f4a9d922p+0, 0x1.13ca058cbae1ep+0, 0x1.13f9d416e77afp+0,
        0x1.1429aaea92de0p+0, 0x1.14598a092ccb7p+0, 0x1.1489717425438p+0, 0x1.14b9612cec861p+0,
        0x1.14e95934f312ep+0, 0x1.1519598da9a9ap+0, 0x1.154962388149ep+0, 0x1.15797336eb333p+0,
        0x1.15a98c8a58e51p+0, 0x1.15d9ae343c1f2p+0, 0x1.1609d83606e12p+0, 0x1.163a0a912b6acp+0,
        0x1.166a45471c3c2p+0, 0x1.169a88594c157p+0, 0x1.16cad3c92df73p+0, 0x1.16fb279835224p+0,
        0x1.172b83c7d517bp+0, 0x1.175be85981992p+0, 0x1.178c554eaea89p+0, 0x1.17bccaa8d0888p+0,
        0x1.17ed48695bbc0p+0, 0x1.181dce91c506ap+0, 0x1.184e5d23816c9p+0, 0x1.187ef4200632bp+0,
        0x1.18af9388c8deap+0, 0x1.18e03b5f3f36bp+0, 0x1.1910eba4df41fp+0, 0x1.1941a45b1f487p+0,
        0x1.1972658375d2fp+0, 0x1.19a32f1f59ab4p+0, 0x1.19d4013041dc2p+0, 0x1.1a04dbb7a5b13p+0,
        0x1.1a35beb6fcb75p+0, 0x1.1a66aa2fbebc7p+0, 0x1.1a979e2363cf8p+0, 0x1.1ac89a936440dp+0,
        0x1.1af99f8138a1cp+0, 0x1.1b2aacee59c53p+0, 0x1.1b5bc2dc40bf0p+0, 0x1.1b8ce14c66e4cp+0,
        0x1.1bbe084045cd4p+0, 0x1.1bef37b95750bp+0, 0x1.1c206fb91588fp+0, 0x1.1c51b040fad15p+0,
        0x1.1c82f95281c6bp+0, 0x1.1cb44aef2547ap+0, 0x1.1ce5a51860746p+0, 0x1.1d1707cfaeaedp+0,
        0x1.1d4873168b9aap+0, 0x1.1d79e6ee731d7p+0, 0x1.1dab6358e15e8p+0, 0x1.1ddce85752c71p+0,
        0x1.1e0e75eb44027p+0, 0x1.1e400c1631fdbp+0, 0x1.1e71aad999e82p+0, 0x1.1ea35236f9330p+0,
        0x1.1ed5022fcd91dp+0, 0x1.1f06bac594fa0p+0, 0x1.1f387bf9cda38p+0, 0x1.1f6a45cdf6085p+0,
        0x1.1f9c18438ce4dp+0, 0x1.1fcdf35c1137ap+0, 0x1.1fffd7190241ep+0, 0x1.2031c37bdf872p+0,
        0x1.2063b88628cd6p+0, 0x1.2095b6395e1d2p+0, 0x1.20c7bc96ffc18p+0, 0x1.20f9cba08e483p+0,
        0x1.212be3578a819p+0, 0x1.215e03bd7580cp+0, 0x1.21902cd3d09b9p+0, 0x1.21c25e9c1d6aap+0,
        0x1.21f49917ddc96p+0, 0x1.2226dc4893d64p+0, 0x1.2259282fc1f27p+0, 0x1.228b7cceeac25p+0,
        0x1.22bdda27912d1p+0, 0x1.22f0403b385d2p+0, 0x1.2322af0b63bffp+0, 0x1.2355269997062p+0,
        0x1.2387a6e756238p+0, 0x1.23ba2ff6254f4p+0, 0x1.23ecc1c78903ap+0, 0x1.241f5c5d05fe6p+0,
        0x1.2451ffb82140ap+0, 0x1.2484abda600efp+0, 0x1.24b760c547f15p+0, 0x1.24ea1e7a5eb35p+0,
        0x1.251ce4fb2a63fp+0, 0x1.254fb44931561p+0, 0x1.25828c65fa1ffp+0, 0x1.25b56d530b9bcp+0,
        0x1.25e85711ece75p+0, 0x1.261b49a425645p+0, 0x1.264e450b3cb82p+0, 0x1.26814948bacc3p+0,
        0x1.26b4565e27cddp+0, 0x1.26e76c4d0c2e5p+0, 0x1.271a8b16f0a30p+0, 0x1.274db2bd5e254p+0,
        0x1.2780e341ddf29p+0, 0x1.27b41ca5f98cbp+0, 0x1.27e75eeb3ab98p+0, 0x1.281aaa132b832p+0,
        0x1.284dfe1f56381p+0, 0x1.28815b11456b1p+0, 0x1.28b4c0ea83f36p+0, 0x1.28e82fac9cecap+0,
        0x1.291ba7591bb70p+0, 0x1.294f27f18bf72p+0, 0x1.2982b17779965p+0, 0x1.29b643ec70c27p+0,
        0x1.29e9df51fdee1p+0, 0x1.2a1d83a9add08p+0, 0x1.2a5130f50d65cp+0, 0x1.2a84e735a9eecp+0,
        0x1.2ab8a66d10f13p+0, 0x1.2aec6e9cd037bp+0, 0x1.2b203fc675d1fp+0, 0x1.2b5419eb90148p+0,
        0x1.2b87fd0dad990p+0, 0x1.2bbbe92e5d3e3p+0, 0x1.2befde4f2e280p+0, 0x1.2c23dc71afbf7p+0,
        0x1.2c57e39771b2fp+0, 0x1.2c8bf3c203f5fp+0, 0x1.2cc00cf2f6c18p+0, 0x1.2cf42f2bda93dp+0,
        0x1.2d285a6e4030bp+0, 0x1.2d5c8ebbb8a15p+0, 0x1.2d90cc15d5346p+0, 0x1.2dc5127e277e3p+0,
        0x1.2df961f641589p+0, 0x1.2e2dba7fb4e33p+0, 0x1.2e621c1c14833p+0, 0x1.2e9686ccf2e3bp+0,
        0x1.2ecafa93e2f56p+0, 0x1.2eff777277ef0p+0, 0x1.2f33fd6a454d2p+0, 0x1.2f688c7cded23p+0,
        0x1.2f9d24abd886bp+0, 0x1.2fd1c5f8c6b93p+0, 0x1.300670653dfe4p+0, 0x1.303b23f2d330bp+0,
        0x1.306fe0a31b715p+0, 0x1.30a4a677ac276p+0, 0x1.30d975721b004p+0, 0x1.310e4d93fdefbp+0,
        0x1.31432edeeb2fdp+0, 0x1.3178195479413p+0, 0x1.31ad0cf63eeacp+0, 0x1.31e209c5d33a0p+0,
        0x1.32170fc4cd831p+0, 0x1.324c1ef4c560ap+0, 0x1.3281375752b40p+0, 0x1.32b658ee0da54p+0,
        0x1.32eb83ba8ea32p+0, 0x1.3320b7be6e633p+0, 0x1.3355f4fb45e20p+0, 0x1.338b3b72ae62dp+0,
        0x1.33c08b26416ffp+0, 0x1.33f5e41798daap+0, 0x1.342b46484ebb4p+0, 0x1.3460b1b9fd712p+0,
        0x1.3496266e3fa2dp+0, 0x1.34cba466b03e1p+0, 0x1.35012ba4ea77dp+0, 0x1.3536bc2a89cc4p+0,
        0x1.356c55f929ff1p+0, 0x1.35a1f912671b1p+0, 0x1.35d7a577dd72bp+0, 0x1.360d5b2b299fcp+0,
        0x1.36431a2de883bp+0, 0x1.3678e281b7475p+0, 0x1.36aeb428335b4p+0, 0x1.36e48f22fa77cp+0,
        0x1.371a7373aa9cbp+0, 0x1.3750611be211cp+0, 0x1.3786581d3f669p+0, 0x1.37bc587961726p+0,
        0x1.37f26231e754ap+0, 0x1.3828754870746p+0, 0x1.385e91be9c811p+0, 0x1.3894b7960b71fp+0,
        0x1.38cae6d05d866p+0, 0x1.39011f6f3345fp+0, 0x1.393761742d808p+0, 0x1.396dace0ed4e1p+0,
        0x1.39a401b7140efp+0, 0x1.39da5ff8436bcp+0, 0x1.3a10c7a61d55bp+0, 0x1.3a4738c244064p+0,
        0x1.3a7db34e59ff7p+0, 0x1.3ab4374c020bdp+0, 0x1.3aeac4bcdf3eap+0, 0x1.3b215ba294f39p+0,
        0x1.3b57fbfec6cf4p+0, 0x1.3b8ea5d318befp+0, 0x1.3bc559212ef89p+0, 0x1.3bfc15eaadfb1p+0,
        0x1.3c32dc313a8e5p+0, 0x1.3c69abf679c2ep+0, 0x1.3ca0853c10f28p+0, 0x1.3cd76803a5c00p+0,
        0x1.3d0e544ede173p+0, 0x1.3d454a1f602d0p+0, 0x1.3d7c4976d27fap+0, 0x1.3db35256dbd67p+0,
        0x1.3dea64c123422p+0, 0x1.3e2180b7501ccp+0, 0x1.3e58a63b0a09bp+0, 0x1.3e8fd54df8f5cp+0,
        0x1.3ec70df1c5175p+0, 0x1.3efe502816ee3p+0, 0x1.3f359bf29743fp+0, 0x1.3f6cf152ef2b8p+0,
        0x1.3fa4504ac801cp+0, 0x1.3fdbb8dbcb6d2p+0, 0x1.40132b07a35dfp+0, 0x1.404aa6cffa0e5p+0,
        0x1.40822c367a024p+0, 0x1.40b9bb3cce07cp+0, 0x1.40f153e4a136ap+0, 0x1.4128f62f9ef0ep+0,
        0x1.4160a21f72e2ap+0, 0x1.419857b5c901fp+0, 0x1.41d016f44d8f5p+0, 0x1.4207dfdcad153p+0,
        0x1.423fb2709468ap+0, 0x1.42778eb1b0a8bp+0, 0x1.42af74a1af3f1p+0, 0x1.42e764423ddfdp+0,
        0x1.431f5d950a897p+0, 0x1.4357609bc3850p+0, 0x1.438f6d5817663p+0, 0x1.43c783cbb50b4p+0,
        0x1.43ffa3f84b9d4p+0, 0x1.4437cddf8a8fep+0, 0x1.4470018321a1ap+0, 0x1.44a83ee4c0dbdp+0,
        0x1.44e086061892dp+0, 0x1.4518d6e8d965bp+0, 0x1.4551318eb43ecp+0, 0x1.458995f95a532p+0,
        0x1.45c2042a7d232p+0, 0x1.45fa7c23ce7a4p+0, 0x1.4632fde7006f4p+0, 0x1.466b8975c563ep+0,
        0x1.46a41ed1d0057p+0, 0x1.46dcbdfcd34c8p+0, 0x1.471566f8827d0p+0, 0x1.474e19c691265p+0,
        0x1.4786d668b3237p+0, 0x1.47bf9ce09c9abp+0, 0x1.47f86d3001fe5p+0, 0x1.48314758980bfp+0,
        0x1.486a2b5c13cd0p+0, 0x1.48a3193c2a96cp+0, 0x1.48dc10fa920a1p+0, 0x1.491512990013fp+0,
        0x1.494e1e192aed2p+0, 0x1.4987337cc91a5p+0, 0x1.49c052c5916c4p+0, 0x1.49f97bf53affdp+0,
        0x1.4a32af0d7d3dep+0, 0x1.4a6bec100fdbap+0, 0x1.4aa532feaada6p+0, 0x1.4ade83db0687ap+0,
        0x1.4b17dea6db7d7p+0, 0x1.4b514363e2a20p+0, 0x1.4b8ab213d5283p+0, 0x1.4bc42ab86c8f1p+0,
        0x1.4bfdad5362a27p+0, 0x1.4c3739e6717aap+0, 0x1.4c70d073537cap+0, 0x1.4caa70fbc35a1p+0,
        0x1.4ce41b817c114p+0, 0x1.4d1dd00638ed8p+0, 0x1.4d578e8bb586bp+0, 0x1.4d915713adc1ep+0,
        0x1.4dcb299fddd0dp+0, 0x1.4e05063202327p+0, 0x1.4e3eeccbd7b2ap+0, 0x1.4e78dd6f1b6a6p+0,
        0x1.4eb2d81d8abffp+0, 0x1.4eecdcd8e3669p+0, 0x1.4f26eba2e35f0p+0, 0x1.4f61047d48f73p+0,
        0x1.4f9b2769d2ca7p+0, 0x1.4fd5546a3fc17p+0, 0x1.500f8b804f127p+0, 0x1.5049ccadc0412p+0,
        0x1.508417f4531eep+0, 0x1.50be6d55c7ca9p+0, 0x1.50f8ccd3deb0dp+0, 0x1.51333670588bfp+0,
        0x1.516daa2cf6642p+0, 0x1.51a8280b798f4p+0, 0x1.51e2b00da3b14p+0, 0x1.521d423536bbep+0,
        0x1.5257de83f4eefp+0, 0x1.529284fba0d84p+0, 0x1.52cd359dfd53dp+0, 0x1.5307f06ccd8bap+0,
        0x1.5342b569d4f82p+0, 0x1.537d8496d75fcp+0, 0x1.53b85df598d78p+0, 0x1.53f34187ddc28p+0,
        0x1.542e2f4f6ad27p+0, 0x1.5469274e05078p+0, 0x1.54a4298571b06p+0, 0x1.54df35f7766a3p+0,
        0x1.551a4ca5d920fp+0, 0x1.55556d92600f1p+0, 0x1.559098bed1bdfp+0, 0x1.55cbce2cf505bp+0,
        0x1.56070dde910d2p+0, 0x1.564257d56d4a2p+0, 0x1.567dac1351819p+0, 0x1.56b90a9a05c72p+0,
        0x1.56f4736b527dap+0, 0x1.572fe68900573p+0, 0x1.576b63f4d854cp+0, 0x1.57a6ebb0a3c6dp+0,
        0x1.57e27dbe2c4cfp+0, 0x1.581e1a1f3bd60p+0, 0x1.5859c0d59ca07p+0, 0x1.589571e31939fp+0,
        0x1.58d12d497c7fdp+0, 0x1.590cf30a919edp+0, 0x1.5948c32824135p+0, 0x1.59849da3ffa96p+0,
        0x1.59c0827ff07ccp+0, 0x1.59fc71bdc2f8ep+0, 0x1.5a386b5f43d92p+0, 0x1.5a746f664028bp+0,
        0x1.5ab07dd485429p+0, 0x1.5aec96abe0d1fp+0, 0x1.5b28b9ee20d1ep+0, 0x1.5b64e79d138d8p+0,
        0x1.5ba11fba87a03p+0, 0x1.5bdd62484bf56p+0, 0x1.5c19af482fc8fp+0, 0x1.5c5606bc02a6dp+0,
        0x1.5c9268a5946b7p+0, 0x1.5cced506b543ap+0, 0x1.5d0b4be135accp+0, 0x1.5d47cd36e6747p+0,
        0x1.5d84590998b93p+0, 0x1.5dc0ef5b1de9ep+0, 0x1.5dfd902d47c65p+0, 0x1.5e3a3b81e85ecp+0,
        0x1.5e76f15ad2148p+0, 0x1.5eb3b1b9d799ap+0, 0x1.5ef07ca0cbf0fp+0, 0x1.5f2d5211826e8p+0,
        0x1.5f6a320dceb71p+0, 0x1.5fa71c9784c0bp+0, 0x1.5fe411b078d26p+0, 0x1.6021115a7f849p+0,
        0x1.605e1b976dc09p+0, 0x1.609b306918c13p+0, 0x1.60d84fd15612ap+0, 0x1.611579d1fb925p+0,
        0x1.6152ae6cdf6f4p+0, 0x1.618feda3d829fp+0, 0x1.61cd3778bc944p+0, 0x1.620a8bed63d1fp+0,
        0x1.6247eb03a5585p+0, 0x1.628554bd58ee5p+0, 0x1.62c2c91c56acdp+0, 0x1.6300482276fe8p+0,
        0x1.633dd1d1929fdp+0, 0x1.637b662b829f5p+0, 0x1.63b90532205d8p+0, 0x1.63f6aee7458cdp+0,
        0x1.6434634ccc320p+0, 0x1.647222648ea3dp+0, 0x1.64afec30678b7p+0, 0x1.64edc0b231e41p+0,
        0x1.652b9febc8fb7p+0, 0x1.656989df08719p+0, 0x1.65a77e8dcc390p+0, 0x1.65e57df9f096bp+0,
        0x1.6623882552225p+0, 0x1.66619d11cdc5fp+0, 0x1.669fbcc140be7p+0, 0x1.66dde735889b8p+0,
        0x1.671c1c70833f6p+0, 0x1.675a5c740edf5p+0, 0x1.6798a7420a036p+0, 0x1.67d6fcdc5386ap+0,
        0x1.68155d44ca973p+0, 0x1.6853c87d4eb62p+0, 0x1.68923e87bfb7ap+0, 0x1.68d0bf65fdc34p+0,
        0x1.690f4b19e9538p+0, 0x1.694de1a563367p+0, 0x1.698c830a4c8d4p+0, 0x1.69cb2f4a86ccap+0,
        0x1.6a09e667f3bcdp+0, 0x1.6a48a86475795p+0, 0x1.6a877541ee718p+0, 0x1.6ac64d0241683p+0,
        0x1.6b052fa75173ep+0, 0x1.6b441d3301feep+0, 0x1.6b8315a736c75p+0, 0x1.6bc21905d3df0p+0,
        0x1.6c012750bdabfp+0, 0x1.6c404089d8e7dp+0, 0x1.6c7f64b30aa09p+0, 0x1.6cbe93ce38381p+0,
        0x1.6cfdcddd47645p+0, 0x1.6d3d12e21e2fbp+0, 0x1.6d7c62dea2f8ap+0, 0x1.6dbbbdd4bc720p+0,
        0x1.6dfb23c651a2fp+0, 0x1.6e3a94b549e71p+0, 0x1.6e7a10a38cee8p+0, 0x1.6eb9979302bddp+0,
        0x1.6ef9298593ae5p+0, 0x1.6f38c67d286ddp+0, 0x1.6f786e7ba9fefp+0, 0x1.6fb8218301b90p+0,
        0x1.6ff7df9519484p+0, 0x1.7037a8b3daadbp+0, 0x1.70777ce1303f6p+0, 0x1.70b75c1f04a84p+0,
        0x1.70f7466f42e87p+0, 0x1.71373bd3d6551p+0, 0x1.71773c4eaa988p+0, 0x1.71b747e1abb24p+0,
        0x1.71f75e8ec5f74p+0, 0x1.72378057e611ap+0, 0x1.7277ad3ef9011p+0, 0x1.72b7e545ec1a8p+0,
        0x1.72f8286ead08ap+0, 0x1.733876bb29cb8p+0, 0x1.7378d02d50b8fp+0, 0x1.73b934c7107c7p+0,
        0x1.73f9a48a58174p+0, 0x1.743a1f7916e05p+0, 0x1.747aa5953c849p+0, 0x1.74bb36e0b906dp+0,
        0x1.74fbd35d7cbfdp+0, 0x1.753c7b0d785e8p+0, 0x1.757d2df29ce7cp+0, 0x1.75bdec0edbb6bp+0,
        0x1.75feb564267c9p+0, 0x1.763f89f46f40fp+0, 0x1.768069c1a861dp+0, 0x1.76c154cdc4937p+0,
        0x1.77024b1ab6e09p+0, 0x1.77434caa72aa7p+0, 0x1.7784597eeba8fp+0, 0x1.77c5719a15ea6p+0,
        0x1.780694fde5d3fp+0, 0x1.7847c3ac50219p+0, 0x1.7888fda749e5dp+0, 0x1.78ca42f0c88a5p+0,
        0x1.790b938ac1cf6p+0, 0x1.794cef772bcc9p+0, 0x1.798e56b7fcf03p+0, 0x1.79cfc94f2bfffp+0,
        0x1.7a11473eb0187p+0, 0x1.7a52d08880ad9p+0, 0x1.7a94652e958aap+0, 0x1.7ad60532e6d20p+0,
        0x1.7b17b0976cfdbp+0, 0x1.7b59675e20defp+0, 0x1.7b9b2988fb9ecp+0, 0x1.7bdcf719f6bd7p+0,
        0x1.7c1ed0130c132p+0, 0x1.7c60b47635cf9p+0, 0x1.7ca2a4456e7a3p+0, 0x1.7ce49f82b0f24p+0,
        0x1.7d26a62ff86f0p+0, 0x1.7d68b84f407f8p+0, 0x1.7daad5e2850acp+0, 0x1.7decfeebc24fep+0,
        0x1.7e2f336cf4e62p+0, 0x1.7e71736819bcdp+0, 0x1.7eb3bedf2e1b9p+0, 0x1.7ef615d42fa24p+0,
        0x1.7f3878491c491p+0, 0x1.7f7ae63ff260ap+0, 0x1.7fbd5fbab091fp+0, 0x1.7fffe4bb55decp+0,
        0x1.80427543e1a12p+0, 0x1.80851156538bep+0, 0x1.80c7b8f4abaa9p+0, 0x1.810a6c20ea617p+0,
        0x1.814d2add106d9p+0, 0x1.818ff52b1ee50p+0, 0x1.81d2cb0d1736ap+0, 0x1.8215ac84fb2a6p+0,
        0x1.82589994cce13p+0, 0x1.829b923e8ed53p+0, 0x1.82de968443d9ap+0, 0x1.8321a667ef1b2p+0,
        0x1.8364c1eb941f7p+0, 0x1.83a7e91136c5dp+0, 0x1.83eb1bdadb46dp+0, 0x1.842e5a4a8634ap+0,
        0x1.8471a4623c7adp+0, 0x1.84b4fa24035eap+0, 0x1.84f85b91e07f1p+0, 0x1.853bc8add9d4cp+0,
        0x1.857f4179f5b21p+0, 0x1.85c2c5f83ac35p+0, 0x1.8606562ab00ecp+0, 0x1.8649f2135cf48p+0,
        0x1.868d99b4492edp+0, 0x1.86d14d0f7cd1dp+0, 0x1.87150c27004c2p+0, 0x1.8758d6fcdc666p+0,
        0x1.879cad931a436p+0, 0x1.87e08febc3608p+0, 0x1.88247e08e1957p+0, 0x1.886877ec7f144p+0,
        0x1.88ac7d98a6699p+0, 0x1.88f08f0f627cbp+0, 0x1.8934ac52be8f7p+0, 0x1.8978d564c63e7p+0,
        0x1.89bd0a478580fp+0, 0x1.8a014afd08a94p+0, 0x1.8a4597875c644p+0, 0x1.8a89efe88dba1p+0,
        0x1.8ace5422aa0dbp+0, 0x1.8b12c437bf1d4p+0, 0x1.8b574029db01ep+0, 0x1.8b9bc7fb0c302p+0,
        0x1.8be05bad61778p+0, 0x1.8c24fb42ea033p+0, 0x1.8c69a6bdb5598p+0, 0x1.8cae5e1fd35c4p+0,
        0x1.8cf3216b5448cp+0, 0x1.8d37f0a248b7fp+0, 0x1.8d7ccbc6c19e6p+0, 0x1.8dc1b2dad04c4p+0,
        0x1.8e06a5e0866d9p+0, 0x1.8e4ba4d9f60a1p+0, 0x1.8e90afc931857p+0, 0x1.8ed5c6b04b9f6p+0,
        0x1.8f1ae99157736p+0, 0x1.8f60186e68793p+0, 0x1.8fa553499284bp+0, 0x1.8fea9a24e9c5cp+0,
        0x1.902fed0282c8ap+0, 0x1.90754be472760p+0, 0x1.90bab6ccce12cp+0, 0x1.91002dbdab403p+0,
        0x1.9145b0b91ffc6p+0, 0x1.918b3fc142a19p+0, 0x1.91d0dad829e70p+0, 0x1.921681ffece05p+0,
        0x1.925c353aa2fe2p+0, 0x1.92a1f48a640dcp+0, 0x1.92e7bff148396p+0, 0x1.932d977168083p+0,
        0x1.93737b0cdc5e5p+0, 0x1.93b96ac5be7d1p+0, 0x1.93ff669e2802bp+0, 0x1.94456e9832eadp+0,
        0x1.948b82b5f98e5p+0, 0x1.94d1a2f996a33p+0, 0x1.9517cf65253d1p+0, 0x1.955e07fac0ccdp+0,
        0x1.95a44cbc8520fp+0, 0x1.95ea9dac8e658p+0, 0x1.9630faccf9243p+0, 0x1.9677641fe2446p+0,
        0x1.96bdd9a7670b3p+0, 0x1.97045b65a51bap+0, 0x1.974ae95cba768p+0, 0x1.9791838ec57abp+0,
        0x1.97d829fde4e50p+0, 0x1.981edcac37d05p+0, 0x1.98659b9bddb5bp+0, 0x1.98ac66cef66c8p+0,
        0x1.98f33e47a22a2p+0, 0x1.993a220801829p+0, 0x1.9981121235681p+0, 0x1.99c80e685f2b5p+0,
        0x1.9a0f170ca07bap+0, 0x1.9a562c011b66dp+0, 0x1.9a9d4d47f2598p+0, 0x1.9ae47ae3481edp+0,
        0x1.9b2bb4d53fe0dp+0, 0x1.9b72fb1ffd285p+0, 0x1.9bba4dc5a3dd3p+0, 0x1.9c01acc858463p+0,
        0x1.9c49182a3f090p+0, 0x1.9c908fed7d2aap+0, 0x1.9cd81414380f2p+0, 0x1.9d1fa4a09579dp+0,
        0x1.9d674194bb8d5p+0, 0x1.9daeeaf2d0cb8p+0, 0x1.9df6a0bcfc15ep+0, 0x1.9e3e62f564ad5p+0,
        0x1.9e86319e32323p+0, 0x1.9ece0cb98ca4bp+0, 0x1.9f15f4499c647p+0, 0x1.9f5de8508a311p+0,
        0x1.9fa5e8d07f29ep+0, 0x1.9fedf5cba4ce0p+0, 0x1.a0360f4424fcbp+0, 0x1.a07e353c29f50p+0,
        0x1.a0c667b5de565p+0, 0x1.a10ea6b36d1fep+0, 0x1.a156f23701b15p+0, 0x1.a19f4a42c7ca9p+0,
        0x1.a1e7aed8eb8bbp+0, 0x1.a2301ffb99757p+0, 0x1.a2789dacfe68cp+0, 0x1.a2c127ef47a74p+0,
        0x1.a309bec4a2d33p+0, 0x1.a352622f3def6p+0, 0x1.a39b1231475f7p+0, 0x1.a3e3ceccede7cp+0,
        0x1.a42c980460ad8p+0, 0x1.a4756dd9cf36ep+0, 0x1.a4be504f696b1p+0, 0x1.a5073f675f924p+0,
        0x1.a5503b23e255dp+0, 0x1.a599438722c03p+0, 0x1.a5e25893523d4p+0, 0x1.a62b7a4aa29a1p+0,
        0x1.a674a8af46052p+0, 0x1.a6bde3c36f0e6p+0, 0x1.a7072b8950a73p+0, 0x1.a75080031e22bp+0,
        0x1.a799e1330b358p+0, 0x1.a7e34f1b4bf62p+0, 0x1.a82cc9be14dcap+0, 0x1.a876511d9ac32p+0,
        0x1.a8bfe53c12e59p+0, 0x1.a909861bb2e1dp+0, 0x1.a95333beb0b7ep+0, 0x1.a99cee2742c9dp+0,
        0x1.a9e6b5579fdbfp+0, 0x1.aa308951ff14dp+0, 0x1.aa7a6a1897fd2p+0, 0x1.aac457ada2803p+0,
        0x1.ab0e521356ebap+0, 0x1.ab58594bedefap+0, 0x1.aba26d59a09eep+0, 0x1.abec8e3ea86eep+0,
        0x1.ac36bbfd3f37ap+0, 0x1.ac80f6979f340p+0, 0x1.accb3e100301ep+0, 0x1.ad159268a5a1cp+0,
        0x1.ad5ff3a3c2774p+0, 0x1.adaa61c395493p+0, 0x1.adf4dcca5a413p+0, 0x1.ae3f64ba4dec6p+0,
        0x1.ae89f995ad3adp+0, 0x1.aed49b5eb5803p+0, 0x1.af1f4a17a4735p+0, 0x1.af6a05c2b82e9p+0,
        0x1.afb4ce622f2ffp+0, 0x1.afffa3f84858cp+0, 0x1.b04a868742ee4p+0, 0x1.b09576115e994p+0,
        0x1.b0e07298db666p+0, 0x1.b12b7c1ff9c61p+0, 0x1.b17692a8fa8cdp+0, 0x1.b1c1b6361ef31p+0,
        0x1.b20ce6c9a8952p+0, 0x1.b2582465d973cp+0, 0x1.b2a36f0cf3f3ap+0, 0x1.b2eec6c13adddp+0,
        0x1.b33a2b84f15fbp+0, 0x1.b3859d5a5b0b1p+0, 0x1.b3d11c43bbd62p+0, 0x1.b41ca843581bap+0,
        0x1.b468415b749b1p+0, 0x1.b4b3e78e56786p+0, 0x1.b4ff9ade433c6p+0, 0x1.b54b5b4d80d4ap+0,
        0x1.b59728de5593ap+0, 0x1.b5e303930830cp+0, 0x1.b62eeb6ddfc87p+0, 0x1.b67ae07123dc3p+0,
        0x1.b6c6e29f1c52ap+0, 0x1.b712f1fa1177bp+0, 0x1.b75f0e844bfc6p+0, 0x1.b7ab384014f76p+0,
        0x1.b7f76f2fb5e47p+0, 0x1.b843b35578a51p+0, 0x1.b89004b3a7804p+0, 0x1.b8dc634c8d228p+0,
        0x1.b928cf22749e4p+0, 0x1.b9754837a96b7p+0, 0x1.b9c1ce8e77680p+0, 0x1.ba0e62292ad7dp+0,
        0x1.ba5b030a1064ap+0, 0x1.baa7b133751e3p+0, 0x1.baf46ca7a67a7p+0, 0x1.bb413568f255ap+0,
        0x1.bb8e0b79a6f1fp+0, 0x1.bbdaeedc12f82p+0, 0x1.bc27df9285775p+0, 0x1.bc74dd9f4de4fp+0,
        0x1.bcc1e904bc1d2p+0, 0x1.bd0f01c520628p+0, 0x1.bd5c27e2cb5e5p+0, 0x1.bda95b600e20bp+0,
        0x1.bdf69c3f3a207p+0, 0x1.be43ea82a13b5p+0, 0x1.be91462c95b60p+0, 0x1.bedeaf3f6a3c2p+0,
        0x1.bf2c25bd71e09p+0, 0x1.bf79a9a9001d2p+0, 0x1.bfc73b0468d30p+0, 0x1.c014d9d2004aap+0,
        0x1.c06286141b33dp+0, 0x1.c0b03fcd0ea5cp+0, 0x1.c0fe06ff301f4p+0, 0x1.c14bdbacd586ap+0,
        0x1.c199bdd85529cp+0, 0x1.c1e7ad8405be6p+0, 0x1.c235aab23e61ep+0, 0x1.c283b56556999p+0,
        0x1.c2d1cd9fa652cp+0, 0x1.c31ff36385e29p+0, 0x1.c36e26b34e065p+0, 0x1.c3bc679157e38p+0,
        0x1.c40ab5fffd07ap+0, 0x1.c45912019768cp+0, 0x1.c4a77b9881650p+0, 0x1.c4f5f2c715c31p+0,
        0x1.c544778fafb22p+0, 0x1.c59309f4aac9fp+0, 0x1.c5e1a9f8630adp+0, 0x1.c630579d34dddp+0,
        0x1.c67f12e57d14bp+0, 0x1.c6cddbd398ea4p+0, 0x1.c71cb269e601fp+0, 0x1.c76b96aac2686p+0,
        0x1.c7ba88988c933p+0, 0x1.c8098835a3611p+0, 0x1.c8589584661a1p+0, 0x1.c8a7b087346f4p+0,
        0x1.c8f6d9406e7b5p+0, 0x1.c9460fb274c22p+0, 0x1.c99553dfa8313p+0, 0x1.c9e4a5ca6a1f8p+0,
        0x1.ca3405751c4dbp+0, 0x1.ca8372e220e61p+0, 0x1.cad2ee13da7cbp+0, 0x1.cb22770cac0f9p+0,
        0x1.cb720dcef9069p+0, 0x1.cbc1b25d25337p+0, 0x1.cc1164b994d23p+0, 0x1.cc6124e6ac88bp+0,
        0x1.ccb0f2e6d1675p+0, 0x1.cd00cebc68e87p+0, 0x1.cd50b869d8f0fp+0, 0x1.cda0aff187d02p+0,
        0x1.cdf0b555dc3fap+0, 0x1.ce40c8993d63dp+0, 0x1.ce90e9be12cb9p+0, 0x1.cee118c6c4709p+0,
        0x1.cf3155b5bab74p+0, 0x1.cf81a08d5e6ecp+0, 0x1.cfd1f95018d17p+0, 0x1.d022600053845p+0,
        0x1.d072d4a07897cp+0, 0x1.d0c35732f2870p+0, 0x1.d113e7ba2c38cp+0, 0x1.d164863890feep+0,
        0x1.d1b532b08c968p+0, 0x1.d205ed248b287p+0, 0x1.d256b596f948cp+0, 0x1.d2a78c0a43f72p+0,
        0x1.d2f87080d89f2p+0, 0x1.d34962fd2517ap+0, 0x1.d39a638197a3cp+0, 0x1.d3eb72109ef21p+0,
        0x1.d43c8eacaa1d6p+0, 0x1.d48db95828ac7p+0, 0x1.d4def2158a91fp+0, 0x1.d53038e7402cep+0,
        0x1.d5818dcfba487p+0, 0x1.d5d2f0d16a1c3p+0, 0x1.d62461eec14bep+0, 0x1.d675e12a31e7fp+0,
        0x1.d6c76e862e6d3p+0, 0x1.d7190a0529c51p+0, 0x1.d76ab3a99745bp+0, 0x1.d7bc6b75eab1fp+0,
        0x1.d80e316c98398p+0, 0x1.d86005901478fp+0, 0x1.d8b1e7e2d479dp+0, 0x1.d903d8674db2bp+0,
        0x1.d955d71ff6075p+0, 0x1.d9a7e40f43c89p+0, 0x1.d9f9ff37adb4ap+0, 0x1.da4c289baaf6ep+0,
        0x1.da9e603db3285p+0, 0x1.daf0a6203e4f5p+0, 0x1.db42fa45c4dfdp+0, 0x1.db955cb0bfbb6p+0,
        0x1.dbe7cd63a8315p+0, 0x1.dc3a4c60f7feap+0, 0x1.dc8cd9ab294e4p+0, 0x1.dcdf7544b6b92p+0,
        0x1.dd321f301b460p+0, 0x1.dd84d76fd269ep+0, 0x1.ddd79e065807dp+0, 0x1.de2a72f628712p+0,
        0x1.de7d5641c0658p+0, 0x1.ded047eb9d12dp+0, 0x1.df2347f63c159p+0, 0x1.df7656641b78cp+0,
        0x1.dfc97337b9b5fp+0, 0x1.e01c9e7395b56p+0, 0x1.e06fd81a2ece1p+0, 0x1.e0c3202e04c5dp+0,
        0x1.e11676b197d17p+0, 0x1.e169dba768949p+0, 0x1.e1bd4f11f8220p+0, 0x1.e210d0f3c7fbap+0,
        0x1.e264614f5a129p+0, 0x1.e2b8002730c71p+0, 0x1.e30bad7dcee90p+0, 0x1.e35f6955b7b78p+0,
        0x1.e3b333b16ee12p+0, 0x1.e4070c9378842p+0, 0x1.e45af3fe592e8p+0, 0x1.e4aee9f495ddcp+0,
        0x1.e502ee78b3ff6p+0, 0x1.e557018d3970bp+0, 0x1.e5ab2334ac7eep+0, 0x1.e5ff537193e75p+0,
        0x1.e653924676d76p+0, 0x1.e6a7dfb5dcecap+0, 0x1.e6fc3bc24e350p+0, 0x1.e750a66e532ebp+0,
        0x1.e7a51fbc74c83p+0, 0x1.e7f9a7af3c60bp+0, 0x1.e84e3e4933c7ep+0, 0x1.e8a2e38ce53dfp+0,
        0x1.e8f7977cdb740p+0, 0x1.e94c5a1ba18bdp+0, 0x1.e9a12b6bc3181p+0, 0x1.e9f60b6fcc1c7p+0,
        0x1.ea4afa2a490dap+0, 0x1.ea9ff79dc6d14p+0, 0x1.eaf503ccd2be5p+0, 0x1.eb4a1eb9fa9d1p+0,
        0x1.eb9f4867cca6ep+0, 0x1.ebf480d8d786dp+0, 0x1.ec49c80faa594p+0, 0x1.ec9f1e0ed4ac2p+0,
        0x1.ecf482d8e67f1p+0, 0x1.ed49f67070435p+0, 0x1.ed9f78d802dc2p+0, 0x1.edf50a122f9e6p+0,
        0x1.ee4aaa2188510p+0, 0x1.eea059089f2d0p+0, 0x1.eef616ca06dd6p+0, 0x1.ef4be368527f6p+0,
        0x1.efa1bee615a27p+0, 0x1.eff7a945e4487p+0, 0x1.f04da28a52e59p+0, 0x1.f0a3aab5f6609p+0,
        0x1.f0f9c1cb6412ap+0, 0x1.f14fe7cd31c7bp+0, 0x1.f1a61cbdf5be7p+0, 0x1.f1fc60a046a84p+0,
        0x1.f252b376bba97p+0, 0x1.f2a91543ec595p+0, 0x1.f2ff860a70c22p+0, 0x1.f35605cce1613p+0,
        0x1.f3ac948dd7274p+0, 0x1.f403324feb781p+0, 0x1.f459df15b82acp+0, 0x1.f4b09ae1d78a1p+0,
        0x1.f50765b6e4540p+0, 0x1.f55e3f9779ba5p+0, 0x1.f5b5288633625p+0, 0x1.f60c2085ad652p+0,
        0x1.f6632798844f8p+0, 0x1.f6ba3dc155226p+0, 0x1.f7116302bd526p+0, 0x1.f768975f5ac86p+0,
        0x1.f7bfdad9cbe14p+0, 0x1.f8172d74af6e1p+0, 0x1.f86e8f32a4b45p+0, 0x1.f8c600164b6dcp+0,
        0x1.f91d802243c89p+0, 0x1.f9750f592e677p+0, 0x1.f9ccadbdac61dp+0, 0x1.fa245b525f439p+0,
        0x1.fa7c1819e90d8p+0, 0x1.fad3e416ec354p+0, 0x1.fb2bbf4c0ba54p+0, 0x1.fb83a9bbeabd1p+0,
        0x1.fbdba3692d514p+0, 0x1.fc33ac5677ab8p+0, 0x1.fc8bc4866e8adp+0, 0x1.fce3ebfbb7237p+0,
        0x1.fd3c22b8f71f1p+0, 0x1.fd9468c0d49ccp+0, 0x1.fdecbe15f6314p+0, 0x1.fe4522bb02e6ep+0,
        0x1.fe9d96b2a23d9p+0, 0x1.fef619ff7c2b3p+0, 0x1.ff4eaca4391b6p+0, 0x1.ffa74ea381efcp+0,
    };
    double limit = base10 ? 260 : 600;
    int valid = 1;
    for (size_t i = 0; i < count; ++i)
        valid &= (arg[i] >= -limit) & (arg[i] <= limit);
    if (!valid) {
        for (size_t i = 0; i < count; ++i)
            out[i] = base10 ? pow(10, arg[i]) : exp(arg[i]);
        return;
    }
    for (size_t i = 0; i < count; ++i) {
        double x = arg[i];
        double q = x * (base10 ? 0x1.a934f0979a371p+11 : 0x1.71547652b82fep+10);
        int k = (int)(q + copysign(0.5, q));
        double r;
        if (base10) {
            double high = x * 0x1.26bb1bbb00000p+1;
            double low = fma(x, 0x1.26bb1bbb00000p+1, -high);
            low = fma(x, 0x1.554560b752b6bp-33, low);
            r = fma(-(double)k, 0x1.a39ef35793c76p-43,
                    (high - (double)k * 0x1.62e42fee00000p-11) + low);
        } else
            r = fma(-(double)k, 0x1.a39ef35793c76p-43, x - (double)k * 0x1.62e42fee00000p-11);
        double p = 0x1.5555555555555p-3;
        p = fma(p, r, 0x1.0000000000000p-1);
        p = fma(p, r, 0x1.0000000000000p+0);
        p = fma(p, r, 0x1.0000000000000p+0);
        uint64_t index = (uint64_t)(k + 1048576);
        p = p * powers[index & 1023];
        uint64_t bits = ((index >> 10) - 1) << 52;
        double scale;
        memcpy(&scale, &bits, sizeof bits);
        out[i] = scale * p;
    }
}

static inline void tt_reaper_exp_array(size_t count, const double *arg, double *out) {
    tt_reaper_exponential_array(count, arg, out, 0);
}
static inline void tt_reaper_pow10_array(size_t count, const double *arg, double *out) {
    tt_reaper_exponential_array(count, arg, out, 1);
}
#endif
