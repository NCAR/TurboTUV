#ifndef TT_REAPER_FLUX_H
#define TT_REAPER_FLUX_H
#include "model_plan.h"
typedef struct {
    const double *solar, *wavelength;
    double *actinic, *irradiance;
} tt_reaper_flux;
tt_status tt_reaper_delta_eddington_flux_profiled(size_t nr, const tt_radiator *radiators, size_t n,
                                                  size_t nw, const int *nid, const double *path,
                                                  double zenith, const double *surface,
                                                  double scale, double *work, tt_radiation *out,
                                                  tt_diagnostics *diagnostics,
                                                  const unsigned char *roles,
                                                  const tt_reaper_flux *flux);
#endif
