#include "model_internal.h"
#include <stdio.h>
#include <math.h>
int main(int argc,char **argv) {
    tt_config *c=0;tt_model *m=0;tt_error e;const tt_model_result *out;
    if(argc!=2 || tt_config_read_file(argv[1],&c,&e) || tt_model_create(tt_config_root(c),0,&m,&e))return 1;
    if(tt_model_run(m,30,1,&out,&e))return 2;
    size_t nl=m->shape.levels-1,nw=m->shape.wavelengths;
    for(size_t j=0;j<m->radiator_count;++j) {
        size_t zero=0;const tt_radiator *r=m->radiator_views+j;
        for(size_t k=0;k<nl*nw;++k)zero+=r->asymmetry[k]*r->optical_depth[k]*r->single_scattering_albedo[k]==0;
        printf("%s zero moments=%zu/%zu\n",m->radiators[j].name,zero,nl*nw);
    }
    tt_model_destroy(m);tt_config_destroy(c);return 0;
}
